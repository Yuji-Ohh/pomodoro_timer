
  # ポモロードタイマーアプリ

  This is a code bundle for ポモロードタイマーアプリ. The original project is available at https://www.figma.com/design/eG45A8vwrouTt6rY3VXbHL/%E3%83%9D%E3%83%A2%E3%83%AD%E3%83%BC%E3%83%89%E3%82%BF%E3%82%A4%E3%83%9E%E3%83%BC%E3%82%A2%E3%83%97%E3%83%AA.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  